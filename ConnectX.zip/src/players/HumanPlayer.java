package players;

import interfaces.IModel;
import interfaces.IPlayer;

import util.InputUtil;

/**
 * Implementing this player is a basic task.
 * See assignment instructions for what to do.
 * There are also helpful comments in this file (which you can remove).
 *
 * @author <YOUR UUN>
 */
public class HumanPlayer implements IPlayer{
    public HumanPlayer(){}

    public void prepareForGameStart(IModel model, byte playerId){}

    public int chooseMove(){
        System.out.println("Enter column: ");
        return InputUtil.readIntFromUser();
    }
}