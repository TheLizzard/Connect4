package players;

import interfaces.IModel;
import interfaces.IPlayer;

import game.Model;

import java.util.HashMap;
import java.util.BitSet;
import java.util.Random;

/**
 * Implementing this player is an advanced task.
 * See assignment instructions for what to do.
 * If not attempting it, just upload the file as it is.
 *
 * @author <YOUR UUN>
 */

public class CompetitivePlayer implements IPlayer{
    private Model model;
    public boolean player_id;

    public HashMap<Integer, Integer> move_ordering;
    public HashMap<Integer, Integer> cache = new HashMap<Integer, Integer>(50000);

    public int[][] zobrist_random_table;

    public static final boolean USE_HASH = true;
    public static final int INFINITY = 501;
    public static final int BASE_DEPTH = (int) Math.log(Math.pow(7, 10)) + 1; // The +1 is there for a reason.

    public int nodes;
    public int skips;

    public CompetitivePlayer(){}

    public void prepareForGameStart(IModel model, byte playerId){
        this.model = (Model)model;
        this.player_id = (playerId == 1) ? false : true;

        this.move_ordering = new HashMap<Integer, Integer>();
        this.generate_move_ordering(this.model.columns);
        this.init_zobrist();
    }

    public void init_zobrist(){
        Random random_generator = new Random();
        this.zobrist_random_table = new int[this.model.board_size][2];
        for (int i = 0; i < this.model.board_size; i++){
            for (int j = 0; j < 2; j++){
                this.zobrist_random_table[i][j] = random_generator.nextInt(CompetitivePlayer.pow(2, 31)-1);
            }
        }
    }

    public void generate_move_ordering(int columns){
        int diff, this_one;

        int last = columns / 2;
        this.move_ordering.put(0, last);

        for (int i = 1; i < columns; i++){
            diff = (i * CompetitivePlayer.pow(-1, i));
            this_one = last+diff;
            this.move_ordering.put(i, this_one);
            last = this_one;
        }
    }

    public static int pow(int x, int y){
        int output = 1;for (int i = 0; i < y; i++) {output *= x;} return output;
    }

    public int check_forced_move(){
        Model model_copy, model_copy_copy;
        byte we_won = (this.player_id) ? IModel.GAME_STATUS_WIN_2 : IModel.GAME_STATUS_WIN_1;
        byte other_won = (!this.player_id) ? IModel.GAME_STATUS_WIN_2 : IModel.GAME_STATUS_WIN_1;

        // Play winning moves:
        for (int move = 0; move < this.model.columns; move++){
            model_copy = new Model(this.model);
            if (!model_copy.isMoveValid(move)){continue;}
            model_copy.push(move);
            if (model_copy.game_status == we_won){
                return move;
            }
        }

        // Check if other has winning move, if so play it to block them.
        model_copy = new Model(this.model);
        model_copy.active_player = !model_copy.active_player;
        for (int move = 0; move < model_copy.columns; move++){
            model_copy_copy = new Model(model_copy);
            if (!model_copy_copy.isMoveValid(move)){continue;}
            model_copy_copy.push(move);
            if (model_copy_copy.game_status == other_won){
                return move;
            }
        }
        // No forced move:
        return -2;
    }

    public int chooseMove(){
        this.skips = 0;
        this.nodes = 0;

        int forced_move = this.check_forced_move();
        if (forced_move != -2){
            return forced_move;
        }
        int fullness = 0;
        for (int column = 0; column < this.model.columns; column++){
            int bit_index = this.model.pos_to_bit_index(this.model.rows-1, column);
            if (this.model.anything_in_bit_index(bit_index)){
                fullness += 1;
            }
        }

        int effective_columns = this.model.columns - fullness;
        int depth = (int) (CompetitivePlayer.BASE_DEPTH / Math.log(effective_columns));

        System.out.println("################################# fullness: " + fullness);
        System.out.println("################################# depth: " + depth);
        int[] result = this.alphabeta(this.model, depth);
        int eval = result[1];
        int move = result[0];
        System.out.println("################################# eval: " + eval);
        System.out.println("################################# nodes: " + nodes);
        System.out.println("################################# skips: " + skips);
        return move;
    }

    // Returns best move:
    public int[] alphabeta(Model model, int depth){
        this.nodes += 1;
        if (model.game_status != IModel.GAME_STATUS_ONGOING){
            throw new RuntimeException("Game ended already");
        }
        if (depth <= 0){
            throw new RuntimeException("`depth` should be > 0");
        }

        this.cache.clear();

        int alpha = -2*CompetitivePlayer.INFINITY;
        int beta = 2*CompetitivePlayer.INFINITY;
        boolean maxing_player = (model.active_player == this.player_id);
        int move, raw_move;

        if (maxing_player){
            int best_move = -1;
            int best_value = -2*CompetitivePlayer.INFINITY;
            for (raw_move = 0; raw_move < model.columns; raw_move++){
                move = this.move_ordering.get(raw_move);
                if (!model.isMoveValid(move)){continue;}

                Model child = new Model(model);
                child.push(move); // push has no guards but is faster

                int new_value = this._alphabeta(child, depth-1, alpha, beta, false);
                if (new_value > best_value){
                    best_value = new_value;
                    best_move = move;
                }
                alpha = Math.max(alpha, best_value);
            }
            int[] r = {best_move, best_value};
            return r;
        }else{
            int best_move = -1;
            int best_value = 2*CompetitivePlayer.INFINITY;
            for (raw_move = 0; raw_move < model.columns; raw_move++){
                move = this.move_ordering.get(raw_move);
                if (!model.isMoveValid(move)){continue;}

                Model child = new Model(model);
                child.push(move); // push has no guards but is faster

                int new_value = this._alphabeta(child, depth-1, alpha, beta, true);
                if (new_value < best_value){
                    best_value = new_value;
                    best_move = move;
                }
                beta = Math.min(beta, best_value);
            }
            int[] r = {best_move, best_value};
            return r;
        }
    }

    // Returns best eval:
    public int _alphabeta(Model model, int depth, int alpha, int beta, boolean maxing_player){
        // This is basically the same as:
        // https://en.wikipedia.org/wiki/Alpha%E2%80%93beta_pruning
        // That is what I used for my chess engine as well (which I coded in C++ and another one in python)
        this.nodes += 1;
        if ((depth == 0) || (model.game_status != IModel.GAME_STATUS_ONGOING)){
            return this.eval_state(model, depth);
        }
        if (CompetitivePlayer.USE_HASH){
            int model_hash = model.hash(this.zobrist_random_table);
            if (this.cache.containsKey(model_hash)){
                this.skips += 1;
                return this.cache.get(model_hash);
            }
        }
        int value, move, raw_move;
        if (maxing_player){
            value = -2*CompetitivePlayer.INFINITY;
            for (raw_move = 0; raw_move < model.columns; raw_move++){
                move = this.move_ordering.get(raw_move);
                if (!model.isMoveValid(move)){continue;}

                Model child = new Model(model);
                child.push(move); // push has no guards but is faster

                int child_value = this._alphabeta(child, depth-1, alpha, beta, false);
                value = Math.max(value, child_value);

                if (value >= beta){break;}

                alpha = Math.max(alpha, value);
            }
        }else{
            value = 2*CompetitivePlayer.INFINITY;
            for (raw_move = 0; raw_move < model.columns; raw_move++){
                move = this.move_ordering.get(raw_move);
                if (!model.isMoveValid(move)){continue;}

                Model child = new Model(model);
                child.push(move); // push has no guards but is faster

                int child_value = this._alphabeta(child, depth-1, alpha, beta, true);
                value = Math.min(value, child_value);

                if (value <= alpha){break;}
                beta = Math.min(beta, value);
            }
        }
        if (CompetitivePlayer.USE_HASH){this.cache.put(model.hash(this.zobrist_random_table), value);}
        return value;
    }

    public int eval_state(Model model, int depth){
        switch (model.game_status){
            // Game still going on
            case IModel.GAME_STATUS_ONGOING: {
//                 return 0;
                return this._eval_state(model);
            }
            case IModel.GAME_STATUS_WIN_1: {
                if (this.player_id){
                    return -CompetitivePlayer.INFINITY-depth;
                }else{
                    return CompetitivePlayer.INFINITY+depth;
                }
            }
            case IModel.GAME_STATUS_WIN_2: {
                if (this.player_id){
                    return CompetitivePlayer.INFINITY+depth;
                }else{
                    return -CompetitivePlayer.INFINITY-depth;
                }
            }
            // Board full
            default:
                return 0;
        }
    }

    public static int max_list(int[] list){
        // Assumes the list is not empty
        int max = list[0];
        for (int i: list){
            max = Math.max(max, i);
        }
        return max;
    }

    public int _eval_state(Model model){
//         int penalty = 0;
        BitSet our_bitset = this.get_our_bitset(model);
        int[] row_sizes = new int[model.columns];
        for (int column = 0; column < model.columns; column++){
            int ours = 0;
            for (int row = model.rows-1; row >= 0; row--){
                int bit_index = model.pos_to_bit_index(row, column);
                if (our_bitset.get(bit_index)){
                    ours += 1;
                }
            }
            row_sizes[column] = ours;
        }
        int penalty = Math.max(3, max_list(row_sizes))-3;
        penalty += 5*(this.number_opposite_threats(model) - this.number_of_threats(model));
        if (!this.player_id){
            penalty = -penalty;
        }
        return penalty;
    }

    public BitSet get_our_bitset(Model model){
        if (this.player_id){
            return model.ys;
        }
        return model.xs;
    }

    public int number_opposite_threats(Model mode){
        Model model_copy = new Model(model);
        model_copy.active_player = !model_copy.active_player;
        return this.number_of_threats(model_copy);
    }

    public int number_of_threats(Model model){
        int threats = 0;

        for (int move = 0; move < model.columns; move++){
            Model model_copy = new Model(model);
            if (!model_copy.isMoveValid(move)){continue;}
            model_copy.push(move);
            if (model_copy.game_status != IModel.GAME_STATUS_ONGOING){
                threats += 1;
            }
        }
        return threats;
    }
}