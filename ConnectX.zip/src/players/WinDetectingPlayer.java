package players;

import interfaces.IModel;
import interfaces.IPlayer;

import game.Model;

/**
 * Implementing this player is an advanced task.
 * See assignment instructions for what to do.
 * If not attempting it, just upload the file as it is.
 *
 * @author <YOUR UUN>
 */
public class WinDetectingPlayer implements IPlayer{
    private Model model;
    boolean player_id;

    public WinDetectingPlayer(){}

    public void prepareForGameStart(IModel model, byte player_id){
        this.model = (Model)model;
        this.player_id = (player_id == 1) ? false : true;
    }

    public int chooseMove(){
        boolean[] winning_moves = new boolean[this.model.columns];
        boolean[] legal_moves = new boolean[this.model.columns];
        boolean winning_move_available = false;

        // Only winning moves are allowed
        for (int move = 0; move < this.model.columns; move++){
            if (this.model.isMoveValid(move)){
                legal_moves[move] = true;
                if (this.check_game_won_on_move(this.model, move)){
                    winning_moves[move] = true;
                    winning_move_available = true;
                }
            }
        }
        if (winning_move_available){
            legal_moves = winning_moves;
        }else{
            // This is so unoptimised but optimisations are unneeded right now
            Model model_copy;
            for (int move = 0; move < this.model.columns; move++){
                if (legal_moves[move]){
                    model_copy = new Model(this.model);
                    model_copy.makeMove(move);
                    for (int opponent_move = 0; opponent_move < this.model.columns; opponent_move++){
                        if (check_game_won_on_move(model_copy, opponent_move)){
                            legal_moves[move] = false;
                        }
                    }
                }
            }
        }

        for (int move = 0; move < this.model.columns; move++){
            if (legal_moves[move]){
                return move;
            }
        }
        // No legal moves
        return -1;
    }

    public boolean check_game_won_on_move(Model model, int move){
        Model model_copy = new Model(model);
        model_copy.makeMove(move);
        return ((model_copy.game_status == IModel.GAME_STATUS_WIN_1) || (model_copy.game_status == IModel.GAME_STATUS_WIN_2));
    }
}