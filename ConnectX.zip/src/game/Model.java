package game;

import interfaces.IModel;
import util.GameSettings;

import java.util.BitSet;

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.File;

/**
 * This class represents the state of the game.
 * It has been partially implemented, but needs to be completed by you.
 *
 * @author <YOUR UUN>
 */



public class Model implements IModel{
    private GameSettings settings;

    // A cache of the settings
    public int rows;
    public int columns;
    public int streak_length;

    // Cache of `rows*columns`
    public int board_size;

    public BitSet xs;
    public BitSet ys;

    public boolean active_player = false;
    public byte game_status = IModel.GAME_STATUS_ONGOING;

    // 4 special constants (depends on rows and columns)
    public BitSet diagonal_1;
    public BitSet diagonal_2;
    public BitSet horizontal;
    public BitSet vertical;

    public Model(){}

    public Model(Model model){
        this.rows = model.rows;
        this.columns = model.columns;
        this.streak_length = model.streak_length;

        this.board_size = model.board_size;
        this.active_player = model.active_player;
        this.game_status = model.game_status;

        this.diagonal_1 = model.diagonal_1;
        this.diagonal_2 = model.diagonal_2;
        this.horizontal = model.horizontal;
        this.vertical = model.vertical;

        this.xs = (BitSet)(model.xs.clone());
        this.ys = (BitSet)(model.ys.clone());

        this.settings = new GameSettings(this.rows, this.columns, this.streak_length);
    }

    // Zorbist hash. Needs to be given a table to work with.
    public int hash(int[][] zobrist_random_table){
        int hash = 0;
        for (int bit_index = 0; bit_index < this.board_size; bit_index++){
            int piece = -1;
            if (this.xs.get(bit_index)){
                piece = 0;
            }else if (this.ys.get(bit_index)){
                piece = 1;
            }
            if (piece != -1){
                hash ^= zobrist_random_table[bit_index][piece];
            }
        }
        return hash;
    }

    public void initNewGame(GameSettings settings){
        this.settings = settings;

        this.active_player = false;
        this.game_status = IModel.GAME_STATUS_ONGOING;

        this.rows = settings.nrRows;
        this.columns = settings.nrCols;
        this.streak_length = settings.minStreakLength;

        this.board_size = this.rows*this.columns;

        this.xs = new BitSet(this.board_size);
        this.ys = new BitSet(this.board_size);

        // The "/" diagonal:
        this.diagonal_1 = new BitSet(this.board_size);
        for (int i = 0; i < this.streak_length; i++){
            this.diagonal_1.set(this.pos_to_bit_index(i, i));
        }
        // The "\" diagonal:
        this.diagonal_2 = new BitSet(this.board_size);
        for (int i = 0; i < this.streak_length; i++){
            this.diagonal_2.set(this.pos_to_bit_index(this.streak_length-i-1, i));
        }
        this.horizontal = new BitSet(this.board_size);
        for (int i = 0; i < this.streak_length; i++){
            this.horizontal.set(this.pos_to_bit_index(0, i));
        }
        this.vertical = new BitSet(this.board_size);
        for (int i = 0; i < this.streak_length; i++){
            this.vertical.set(this.pos_to_bit_index(i, 0));
        }
    }

    public void initSavedGame(String file_name){
        try{
            File file = new File("saves/"+file_name);
            Scanner reader = new Scanner(file);

            rows = Integer.parseInt(reader.nextLine());
            columns = Integer.parseInt(reader.nextLine());
            streak_length = Integer.parseInt(reader.nextLine());

            this.initNewGame(new GameSettings(rows, columns, streak_length));

            this.active_player = (reader.nextLine().equals("1")) ? false : true;

            for (int row = 1; row <= rows; row++){
                String line = reader.nextLine();
                for (int column = 0; column < columns; column++){
                    int bit_index = this.pos_to_bit_index(rows-row, column);
                    switch (line.charAt(column)){
                        case '0':
                            break;
                        case '1':
                            this.xs.set(bit_index);
                            break;
                        case '2':
                            this.ys.set(bit_index);
                            break;
                        default:
                            throw new RuntimeException("Invalid character in save file.");
                    }
                }
            }

            reader.close();
        } catch (FileNotFoundException error){
            throw new RuntimeException("File doesn't exist!");
        }
    }

    public boolean isMoveValid(int move){
        int number_columns = this.getGameSettings().nrCols;
        // Special condition for -1
        if (move == -1){
            return true;
        }
        if ((move < 0) || (move >= number_columns)){
            return false;
        }
        if (get_free_from_column(move) == -1){
            return false;
        }
        return true;
    }

    public void makeMove(int move){
        // If the player concedes:
        if (move == -1){
            if (this.getActivePlayer() == 1){
                this.game_status = IModel.GAME_STATUS_WIN_2;
            }else{
                this.game_status = IModel.GAME_STATUS_WIN_1;
            }
        }
        // If the game just ended don't move
        if (this.getGameStatus() != IModel.GAME_STATUS_ONGOING){
            return;
        }

        // Do the actual move:
        this.push(move);
    }

    public byte getGameStatus(){
        return this.game_status;
    }

    public byte getActivePlayer(){
        return this.active_player ? (byte)2 : (byte)1;
    }

    public byte getPieceIn(int row, int column){
        int bit_index = this.pos_to_bit_index(this.rows-row-1, column);
        if (this.xs.get(bit_index)){
            return 1;
        }
        if (this.ys.get(bit_index)){
            return 2;
        }
        return 0;
    }

    public GameSettings getGameSettings(){
        return this.settings;
    }

    public void update_game_status(){
        this.check_won();
        if (this.game_status == IModel.GAME_STATUS_ONGOING){
            this.check_draw();
        }
    }

    public void check_draw(){
        int row = this.rows-1;
        for (int column = 0; column < this.columns; column++){
            int bit_index = this.pos_to_bit_index(row, column);
            if (!this.anything_in_bit_index(bit_index)){
                return;
            }
        }
        this.game_status = IModel.GAME_STATUS_TIE;
    }

    public void check_won(){
        BitSet xs, ys;
        // Diagonals:
        xs = this.xs;
        ys = this.ys;
        int rows_minus_streak_length = rows-this.streak_length;
        int columns_minus_streak_length = columns-this.streak_length;
        for (int i = 0; i < this.rows; i++){
            for (int j = 0; j < this.columns; j++){
                if (j <= columns_minus_streak_length){
                    // Apply horizontal mask:
                    if (this.and_with_mask_bitsets(xs, this.horizontal)){
                        this.game_status = IModel.GAME_STATUS_WIN_1;
                    }
                    if (this.and_with_mask_bitsets(ys, this.horizontal)){
                        this.game_status = IModel.GAME_STATUS_WIN_2;
                    }
                    if (i <= rows_minus_streak_length){
                        // Apply diagonal mask:
                        if (this.and_with_mask_bitsets(xs, this.diagonal_1) || this.and_with_mask_bitsets(xs, this.diagonal_2)){
                            this.game_status = IModel.GAME_STATUS_WIN_1;
                        }
                        if (this.and_with_mask_bitsets(ys, this.diagonal_1) || this.and_with_mask_bitsets(ys, this.diagonal_2)){
                            this.game_status = IModel.GAME_STATUS_WIN_2;
                        }
                    }
                }
                if (i <= rows_minus_streak_length){
                    // Apply vertical mask:
                    if (this.and_with_mask_bitsets(xs, this.vertical)){
                        this.game_status = IModel.GAME_STATUS_WIN_1;
                    }
                    if (this.and_with_mask_bitsets(ys, this.vertical)){
                        this.game_status = IModel.GAME_STATUS_WIN_2;
                    }
                }
                // Shift everything
                xs = this.bit_shift_right(xs, 1);
                ys = this.bit_shift_right(ys, 1);
            }
        }
    }

//     public void check_won(){
//         BitSet xs, ys;
//         // Diagonals:
//         xs = this.xs;
//         ys = this.ys;
//         for (int i = 0; i <= rows-this.streak_length; i++){
//             for (int j = 0; j <= columns-this.streak_length; j++){
//                 // Apply diagonal mask:
//                 if (this.and_with_mask_bitsets(xs, this.diagonal_1) || this.and_with_mask_bitsets(xs, this.diagonal_2)){
//                     this.game_status = IModel.GAME_STATUS_WIN_1;
//                 }
//                 if (this.and_with_mask_bitsets(ys, this.diagonal_1) || this.and_with_mask_bitsets(ys, this.diagonal_2)){
//                     this.game_status = IModel.GAME_STATUS_WIN_2;
//                 }
//                 // Shift everything
//                 xs = this.bit_shift_right(xs, 1);
//                 ys = this.bit_shift_right(ys, 1);
//             }
//             xs = this.bit_shift_right(xs, this.streak_length-1);
//             ys = this.bit_shift_right(ys, this.streak_length-1);
//         }
//         // Horizontals:
//         xs = this.xs;
//         ys = this.ys;
//         for (int i = 0; i < rows; i++){
//             for (int j = 0; j < columns-this.streak_length+1; j++){
//                 // Apply diagonal mask:
//                 if (this.and_with_mask_bitsets(xs, this.horizontal)){
//                     this.game_status = IModel.GAME_STATUS_WIN_1;
//                 }
//                 if (this.and_with_mask_bitsets(ys, this.horizontal)){
//                     this.game_status = IModel.GAME_STATUS_WIN_2;
//                 }
//                 // Shift everything
//                 xs = this.bit_shift_right(xs, 1);
//                 ys = this.bit_shift_right(ys, 1);
//             }
//             xs = this.bit_shift_right(xs, this.streak_length-1);
//             ys = this.bit_shift_right(ys, this.streak_length-1);
//         }
//         // Verticals:
//         xs = this.xs;
//         ys = this.ys;
//         for (int i = 0; i < rows-this.streak_length+1; i++){
//             for (int j = 0; j < columns; j++){
//                 // Apply diagonal mask:
//                 if (this.and_with_mask_bitsets(xs, this.vertical)){
//                     this.game_status = IModel.GAME_STATUS_WIN_1;
//                 }
//                 if (this.and_with_mask_bitsets(ys, this.vertical)){
//                     this.game_status = IModel.GAME_STATUS_WIN_2;
//                 }
//                 // Shift everything
//                 xs = this.bit_shift_right(xs, 1);
//                 ys = this.bit_shift_right(ys, 1);
//             }
//         }
//     }

    public void push(int column){
        BitSet players_bitset;
        if (this.active_player){
            players_bitset = this.ys;
        }else{
            players_bitset = this.xs;
        }
        int row = this.get_free_from_column(column);
        if (row == -1){
            return;
        }
        int bit_index = this.pos_to_bit_index(row, column);
        players_bitset.set(bit_index);
        this.active_player = !this.active_player;

        this.update_game_status();
    }

    public int get_free_from_column(int column){
        for (int row = 0; row < rows; row++){
            int bit_index = this.pos_to_bit_index(row, column);
            if (!(this.xs.get(bit_index) || this.ys.get(bit_index))){
                return row;
            }
        }
        return -1;
    }

    public int pos_to_bit_index(int row, int column){
        return row * this.columns + column;
    }

    public boolean anything_in_bit_index(int bit_index){
        return this.xs.get(bit_index) || this.ys.get(bit_index);
    }

    public BitSet bit_shift_right(BitSet bit_set, int n){
        return bit_set.get(n, n+this.board_size - 1);
    }

    public boolean and_with_mask_bitsets(BitSet bitset, BitSet mask){
        bitset = (BitSet)bitset.clone();
        bitset.and(mask);
        return bitset.equals(mask);
    }
}