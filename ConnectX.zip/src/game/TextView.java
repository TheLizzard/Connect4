package game;

import interfaces.*;
import players.*;
import util.GameSettings;
import util.InputUtil;

/**
 * This class is used to interact with the user.
 * It has been partially implemented, but needs to be completed by you.
 *
 * @author <YOUR UUN>
 */
public class TextView implements IView{
    public void displayWelcomeMessage(){
        System.out.println("Welcome to Connect Four!");
    }
    
    public void displayChosenMove(int move){
        System.out.println("Selected move: " + move);
    }
    
    public void displayMoveRejectedMessage(int move){
        System.out.println("The move (" + move + ") was rejected, please try again.");
    }
    
    public void displayActivePlayer(byte playerID){
        System.out.println("\nPlayer " + playerID + " is next!");
    }
    
    public void displayGameStatus(byte gameStatus){
        System.out.print("\nGame status: ");
        
        switch(gameStatus){
            case IModel.GAME_STATUS_ONGOING: System.out.println("The game is in progress."); break;
            case IModel.GAME_STATUS_WIN_1: System.out.println("Player 1 has won!"); break;
            case IModel.GAME_STATUS_WIN_2: System.out.println("Player 2 has won!"); break;
            case IModel.GAME_STATUS_TIE: System.out.println("The game has ended in a tie!"); break;
            default: System.out.println("Error: Invalid/unknown game status"); break;
        }
    }

    public void displayBoard(IModel model){
        System.out.println("\n-------- BOARD --------");

        int nrRows = model.getGameSettings().nrRows;
        int nrCols = model.getGameSettings().nrCols;

        // Here is an example of how the output should look:
        //_ _ O O _ _ X
        //_ _ X O _ _ X
        //_ O X X _ _ O
        //_ X X O _ X O
        //X O O X O O O
        //X O X X X O X

        for (int row=0; row < nrRows; row++){
            for (int column=0; column < nrCols; column++){
                int piece = model.getPieceIn(row, column);
                switch (piece){
                    case 0:
                        System.out.print("_ ");
                        break;
                    case 1:
                        System.out.print("X ");
                        break;
                    case 2:
                        System.out.print("O ");
                        break;
                    default:
                        throw new RuntimeException("Invalid number in the board state.");
                }
            }
            System.out.println();
        }
    }

    public char requestMenuSelection(){
        // Display menu options.
        System.out.println("\n-------- MENU --------");
        System.out.println("(1) Start new game");
        System.out.println("(2) Resume saved game");
        System.out.println("(3) Change game settings");
        System.out.println("(4) Change players");

        // Request and return user input.
        System.out.print("Select an option and confirm with enter or use any other key to quit: ");
        return InputUtil.readCharFromUser();
    }

    public String requestSaveFileName(){
        System.out.println("\n-------- LOAD GAME --------");
        System.out.print("File name (e.g. Save.txt): ");
        return InputUtil.readStringFromUser();
    }
    
    public GameSettings requestGameSettings(){
        System.out.println("\n-------- GAME SETTINGS --------");
        
        // Replace these lines with code that asks the user to enter the values.
        int nrRows = this.get_int("Enter the the number of rows: ", 3, 10);
        int nrCols = this.get_int("Enter the the number of columns: ", 3, 10);
        int streak = this.get_int("Enter the the streak length: ", 2, Math.min(nrRows, nrCols));
        
        // Wrap the selected settings in a GameSettings instance and return (leave this code here).
        return new GameSettings(nrRows, nrCols, streak);
    }

    public int get_int(String message, int min, int max){
        System.out.println(message);
        while (true){
            int uinput = InputUtil.readIntFromUser();
            if ((min <= uinput) && (uinput <= max)){
                return uinput;
            }
        }
    }
    
    public IPlayer requestPlayerSelection(byte playerId){
        System.out.println("\n-------- CHOOSE PLAYER " + playerId + " --------");
        System.out.println("(1) HumanPlayer");
        System.out.println("(2) RoundRobinPlayer");
        System.out.println("(3) WinDetectingPlayer");
        System.out.println("(4) CompetitivePlayer");
        
        // Request user input.
        System.out.print("Select an option and confirm with enter (invalid input will select a HumanPlayer): ");
        char selectedPlayer = InputUtil.readCharFromUser();
        
        // Instantiate the selected player class.
        switch(selectedPlayer){
            case '2': return new RoundRobinPlayer();
            case '3': return new WinDetectingPlayer();
            case '4': return new CompetitivePlayer();
            default: return new HumanPlayer();
        }
    }
}