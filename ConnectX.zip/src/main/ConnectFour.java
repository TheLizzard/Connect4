package main;

import game.Controller;

/**
 * This class creates a controller to start the game.
 * You should not change this class.
 *
 * @author David Symons
 */
public class ConnectFour{
    public static void main(String[] args){
        Controller controller = new Controller();
        controller.startSession();
    }
}


/*

[0, 3, 0, 0, 0, 4, 2, 3, 0, 1, 1, 3, 3, 5, 0, 6]


[4, 4, 1, 1] ++ [3, 0, 4, 3, 1, 3, 5, 6]

*/